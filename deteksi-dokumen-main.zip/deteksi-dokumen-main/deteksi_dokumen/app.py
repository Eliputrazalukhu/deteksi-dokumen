from flask import Flask, render_template, request
import os
from Crypto.Hash import SHA256
from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15

app = Flask(__name__)

UPLOAD_FOLDER = "uploads"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# generate RSA key
key = RSA.generate(2048)
public_key = key.publickey()

signature_data = None

@app.route("/", methods=["GET", "POST"])
def index():

    global signature_data
    result = ""

    if request.method == "POST":

        file = request.files["file"]
        action = request.form["action"]

        filepath = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
        file.save(filepath)

        with open(filepath, "rb") as f:
            data = f.read()

        hash_file = SHA256.new(data)

        if action == "sign":

            signature_data = pkcs1_15.new(key).sign(hash_file)

            result = "Signature berhasil dibuat"

        elif action == "verify":

            try:
                pkcs1_15.new(public_key).verify(hash_file, signature_data)
                result = "Dokumen ASLI (tidak dimodifikasi)"
            except:
                result = "Dokumen TELAH DIMODIFIKASI"

    return render_template("index.html", result=result)

if __name__ == "__main__":
    app.run(debug=True)